<?php

namespace App\Controllers;

use Framework\Controller\BaseController;

class HomeController extends BaseController
{
    public function index()
    {
        echo 'hello';
    }
}
