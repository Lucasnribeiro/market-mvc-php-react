<?php

namespace Framework\Controller;


/**
 * This is the "base controller class". All other "real" controllers extend this class.
 */
class BaseController
{
    
}
